# Forte College of Excellence — Online Project

## اس پیکج میں
- Android app project اور GitHub Actions APK workflow
- Student/Teacher/Admin dashboard interface
- Firebase Email/Password authentication wiring
- Firestore record integration
- Camera QR/barcode scanning interface
- Firestore rules starter
- Firebase configuration template

## موبائل سے APK
1. ZIP کو Android فون میں download کرکے extract کریں۔
2. GitHub میں ایک نئی repository بنائیں۔
3. ZIP کے اندر موجود **تمام items** (including `app` and hidden `.github` folder) کو ان کے exact paths کے ساتھ upload کریں۔ ZIP file کو اکیلا upload نہ کریں۔
4. GitHub → Actions → `Build Forte College APK` → Run workflow۔
5. Successful run میں Artifacts سے `Forte-College-APK` download کریں؛ artifact ZIP extract کریں، پھر `app-debug.apk` install کریں۔

## Firebase online database
1. https://console.firebase.google.com/ کھولیں اور project بنائیں۔
2. Project settings میں Web App register کریں۔
3. Web app config کو `app/src/main/assets/firebase-config.js` میں placeholder values کی جگہ رکھیں۔
4. Authentication → Sign-in method میں Email/Password enable کریں۔
5. Firestore Database create کریں اور `firestore.rules` کے rules publish کریں۔
6. اپنا trusted admin user بنانے کے لیے پہلے normal account register کریں، پھر Firebase Console → Firestore → `users` collection میں اسی UID کے document کا `role` صرف آپ خود `admin` کریں۔ Teacher role بھی صرف trusted admin assign کرے۔
7. Rules کو اپنے use case کے مطابق review/test کیے بغیر real student data استعمال نہ کریں۔

## اہم حدود اور سکیورٹی
- Firebase config اس وقت placeholders ہیں؛ اس لیے online sync اس وقت تک نہیں چلے گا جب تک آپ اپنا project config نہ لگائیں۔
- نئے accounts student role سے شروع ہوتے ہیں؛ teacher/admin role کو trusted admin کو manually assign کرنا ہوگا۔
- Scanner QR/barcode پڑھتا ہے؛ attendance record database میں محفوظ ہونے کے لیے Firebase config اور rules درست ہونا ضروری ہے۔
- یہ first deployable version ہے، independent security audit یا production testing نہیں ہوئی۔ پہلے test accounts اور dummy data استعمال کریں۔
- Free Firebase plan کی quotas/limits ہیں اور وہ وقت کے ساتھ بدل سکتی ہیں۔
