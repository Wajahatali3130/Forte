// REQUIRED: Replace these values with your own Firebase Web App config.
// Firebase Console: https://console.firebase.google.com/
// Never put a service-account private key in this file.
window.FORTE_FIREBASE_CONFIG = {
  apiKey: "PASTE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
